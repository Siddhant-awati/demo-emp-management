var application = angular.module('ctsApplication', ['ngRoute', 'ngMaterial']);
