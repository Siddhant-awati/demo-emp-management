application.controller('registerCtrl', ['$scope','$http', function($scope, $http){
	$scope.registerUser = function(){
		var newUserObject = {
			  "cognizantId": ($scope.cognizantId  * 1),
			  "password":$scope.password,
			  "cognizantMailId":$scope.cognizantMailId,
			  "isUserActive":1
		};

		$http({
		  method: 'POST',
		  url: 'http://localhost:8090/ems/registerUser',
		  data: newUserObject,
		  headers:{
		  	'Accept': '*',
		  	'Content-Type': 'application/json'
		  },		  
		}).then(function successCallback(response) {
			console.log('Success', response);
		    displayAlertMessage('Success', response.data);
		  }, function errorCallback(response) {
			console.log('Error', response);
		    displayAlertMessage('Error', response.data.error);
		 });
		function displayAlertMessage(type, message){
			if(type === 'Success'){
				$scope.registerSuccess = true;
				$scope.registerError = false;
				$scope.cognizantId = '';
				$scope.password = '';
				$scope.cognizantMailId = '';
				$scope.registerSuccessMessage = message;
			}
			else if(type === 'Error'){
				$scope.registerSuccess = false;
				$scope.registerError = true;
				$scope.registerErrorMessage = message;
			}
		}
	}

}])

