application.config(['$routeProvider', function($routeProvider){
	$routeProvider
	.when('/', {
		templateUrl:'../html/components/login.html',
		controller:'loginCtrl'
	})
	.when('/register', {
		templateUrl:'../html/components/register.html'
	})
	.when('/dashboard',{
		// resolve: {
		// check:function ($location, $rootScope){
  //           if(!$rootScope.loggedIn) {
  //           	$location.path('/');
  //           }
  //                   }
		// },
           	templateUrl:'../html/components/dashboard.html'
	
	})
	.otherwise({
		redirectTo:'/'
	});
}])