application.controller('dashboardCtrl', ['$scope', '$http', function($scope, $http) {
    $scope.activeTab = 'cognizantTab';
    $scope.detailsTemp = {};
    $scope.billingDetailsTemp = {};
    $scope.isOverlayActive = false;
    $scope.projectsList = [];

    $scope.showTabContent = function(currentTab) {
        $scope.activeTab = currentTab;
    }

    $scope.formatIsAdmin = function(flag) {
        if (flag === 1)
            return 'Program Lead';
        else if (flag === 2)
            return 'Admin';
        else
            return 'Normal User';
    }

    $http({
        method: 'GET',
        url: '../data/leaves.json',
        headers: {
            'Accept': '*',
            'Content-Type': 'application/json'
        },
    }).then(function successCallback(response) {
        console.log('leaves :', response);
    }, function errorCallback(response) {
        console.log('Error :', response);
    });


    $http({
        method: 'GET',
        url: 'http://localhost:8090//ems/projects',
        headers: {
            'Accept': '*',
            'Content-Type': 'application/json'
        },
    }).then(function successCallback(response) {
        $scope.projectsList = response.data;
    }, function errorCallback(response) {
        console.log('errorCallback', response);
    });

}])

application.controller('associateDetailsCtrl', ['$scope', '$http', function($scope, $http) {
    $scope.viewTypeFlag = 'allView';
    $scope.loggedInUserRole = 'admin';
    $scope.checkIfSelected = '';
    $scope.myLeaveFrom = new Date();
    $scope.myLeaveTo = new Date();
    $scope.detailsTemp.applyLeaveForId = '';

    $scope.getSelectedEmployee = function(obj) {
        $scope.checkIfSelected = obj;
        $scope.detailsTemp.editEmpID = obj.cognizantId;
        $scope.detailsTemp.editEmpName = obj.associateName;
        $scope.detailsTemp.applyLeaveForId = obj.cognizantId;
    }

    // Add New Employee Functionality - START
    $scope.addNewEmployeeOverlay = function() {
        $scope.detailsTemp.addNewEmpOverlayFlag = true;
        $scope.detailsTemp.overlayBackDropFlag = true;
    }
    $scope.detailsTemp.closeAddNewEmpOverlay = function() {
        $scope.detailsTemp.addNewEmpOverlayFlag = false;
        $scope.detailsTemp.overlayBackDropFlag = false;
    }
    $scope.detailsTemp.addNewEmpFunction = function() {
        var newEmpData = {
            "cognizantId": 350067,
            "associateName": "Siddhant Awati",
            "hcmSupervisorId": 137899,
            "hcmSupervisorName": "Niraj Chourasia",
            "locationId": "BEBCBRUA01",
            "techId": "1",
            "potientialFlagForBilling": "1",
            "isAdmin": 2,
            "programid": 1000139361,
            "program": "JAVA PIPELINE",
            "programLead": "Niraj Chourasia",
            "phoneNumber": 32465295765,
            "emergencyContact": 32465295765,
            "technology": "Java",
            "locationName": "Brussels",
            "corpkey": "ii98ab",
            "ingMailId": "sid.awati@ing.com",
            "l4ManagerName": "Mihai Popa",
            "joiningdate": "2017-07-01",
            "enddate": "2017-12-31",
            "subcontractor": "N",
            "poNumber": 27993,
            "contractName": "Java Development",
            "contractDescription": "TDS Java",
            "contractReference": "MA-009369",
            "poDescription": " ",
            "rateId": 1,
            "level": "Advanced Beginner",
            "dailyRate": 411
        };

        $http({
            method: 'POST',
            url: 'http://localhost:8090/ems/addEmployee',
            data: newEmpData,
            headers: {
                'Accept': '*',
                'Content-Type': 'application/json'
            },
        }).then(function successCallback(response) {
            console.log('successCallback', response);
        }, function errorCallback(response) {
            console.log('errorCallback', response);
        });

    }
    $http.get('http://localhost:8090/ems/employees').success(function(response) {
        $scope.employeeDataAll = response;
    });
    // Add New Employee Functionality - END


    // Edit Employee details Functionality - START
    $scope.editEmployeeOverlay = function() {
        $scope.detailsTemp.editEmpOverlayFlag = true;
        $scope.detailsTemp.overlayBackDropFlag = true;
    }
    $scope.detailsTemp.closeEditEmpOverlay = function() {
        console.log('edit');
        $scope.detailsTemp.editEmpOverlayFlag = false;
        $scope.detailsTemp.overlayBackDropFlag = false;
    }
    $scope.detailsTemp.editEmpFunction = function() {
            let selectedEmpID = $scope.checkIfSelected.cognizantId;
            let editEmpData = {
                "cognizantId": 307668,
                "associateName": "Siddhant Awati",
                "hcmSupervisorId": 137899,
                "hcmSupervisorName": "Niraj",
                "locationId": "BEBCBRUA01",
                "techId": "1",
                "potientialFlagForBilling": "1",
                "isAdmin": 2,
                "programid": 101010,
                "program": "JAVA",
                "programLead": "Niraj",
                "phoneNumber": 32465295765,
                "emergencyContact": 32465295765,
                "technology": "Java",
                "locationName": "Brussels",
                "corpkey": "ii98ab",
                "ingMailId": "sid.awati@ing.com",
                "l4ManagerName": "Mihai Popa",
                "joiningdate": "2017-07-01",
                "enddate": "2017-12-31",
                "subcontractor": "N",
                "poNumber": 101010,
                "contractName": "Java",
                "contractDescription": "Java",
                "contractReference": "MA-101010",
                "poDescription": " ",
                "rateId": 1,
                "level": "Beginner",
                "dailyRate": 411
            };
            $http({
                method: 'POST',
                url: 'http://localhost:8090/ems/employees/' + selectedEmpID,
                data: editEmpData,
                headers: {
                    'Accept': '*',
                    'Content-Type': 'application/json'
                },
            }).then(function successCallback(response) {
                console.log('successCallback', response);
            }, function errorCallback(response) {
                console.log('errorCallback', response);
            });
        }
        // Edit Employee details Functionality - END

    // Leave History details - START
    $scope.leaveHistoryOverlay = function() {
        $scope.detailsTemp.overlayBackDropFlag = true;
        $scope.detailsTemp.leaveHistoryOverlayFlag = true;
    }
    $scope.detailsTemp.closeLeaveHistoryOverlay = function() {
            $scope.detailsTemp.overlayBackDropFlag = false;
            $scope.detailsTemp.leaveHistoryOverlayFlag = false;
        }
        // Leave History details - END

    // Add leave for employee - START
    $scope.addLeaveForEmpOverlay = function() {
        $scope.detailsTemp.overlayBackDropFlag = true;
        $scope.detailsTemp.addLeaveOverlayFlag = true;
    }
    $scope.detailsTemp.closeLeaveForEmpOverlay = function() {
            $scope.detailsTemp.overlayBackDropFlag = false;
            $scope.detailsTemp.addLeaveOverlayFlag = false;
        }
        // Add leave for employee - END


}])


application.controller('billingDetailsCtrl', ['$scope', '$http', function($scope, $http) {
    $scope.billingDetailsTemp.selectedProjBilling = 'All';
    $scope.billingDataAll = [];
    $scope.tempBillingDataAll = []
    $scope.billingDetailsTemp.generateBillingDetails = function() {
        $http.get('../data/billing.json').success(function(response) {
            $scope.billingDataAll = response;
            $scope.tempBillingDataAll = response;
            console.log(response);
        });
    };
    $scope.billingDetailsTemp.updateTableByProject = function(){
    	let projectFlag = $scope.billingDetailsTemp.selectedProjBilling;
    	if(projectFlag === 'All'){
    		$scope.billingDataAll = $scope.tempBillingDataAll;
    	}
    	else{
    		$scope.getDataForSelectedProject(projectFlag);
    	}
    }
    $scope.getDataForSelectedProject = function(projectFlag){
    	$scope.billingDataAll = [];
    	$scope.billingDataAll = $scope.tempBillingDataAll.filter(function(obj){
			return obj.project.projectName === projectFlag;
		})
		console.log($scope.billingDataAll);
    }
}]);