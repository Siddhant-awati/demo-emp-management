application.controller('loginCtrl',['$scope', '$location', '$http',  function($scope, $location, $http){
	$scope.validateLogin = function(){
		var userCredentials = {
		  "cognizantId": ($scope.username * 1),
		  "password":$scope.password
		};
		var data = {
		    "cognizantId": 307668,
		    "password":"307668"
		};
		$http({
		  method: 'POST',
		  url: 'http://localhost:8090/ems/isValidUser',
		  data: userCredentials,
		  headers:{
		  	'Accept': '*',
		  	'Content-Type': 'application/json'
		  },		  
		}).then(function successCallback(response) {
		    console.log('successCallback', response.data.validUser);
		    checkValidUser(response.data.validUser);
		  }, function errorCallback(response) {
		    console.log('errorCallback', response.data.validUser);
		    $scope.loginError = true;
		    checkValidUser(true);
		 });

		function checkValidUser(check){
			if(!check){
				$scope.loginError = false;
				$location.path('/dashboard');
			}
			else{
				$scope.loginError = true;
			}
		}
	}

}])
